//1.we create a variable fro XMLHTTPRequest
var request = new XMLHttpRequest();
//2.create a connection
request.open('GET', 'https://restcountries.eu/rest/v2/all', true)
//3.send the request
request.send();
//4.load the data
let countrydata;
let sum = 0;
request.onload = function () {
    countrydata = JSON.parse(this.response);
    console.log("To get count press button on page")
}
//Function to calculate total population of all countries
function myfunction() {
    console.clear()
    for (let i in countrydata) {
        sum = sum + countrydata[i].population
    }
    document.getElementById("demo").innerHTML = "Total Population of all countries together " + sum;
    console.log("Total Poplation of all countries")
    console.log(sum)
    sum=0;
    /*document.getElementById("Display").onclick = function () {
        //disable
        this.disabled = true;
    }*/
  
}

